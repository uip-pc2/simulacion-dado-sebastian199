# simulacion-dado
Información sobre asignación donde se simula el comportamiento de un sistema de elevadores.

## Descripción del Problema
Desarrollo un programa de línea de comandos que simule el lanzamiento de un dado de seis lados. Usted debe representar el dado como una clase, incluyendo como característica el resultado de cada uno de los lanzamientos realizados y como acción lanzarlo.

No es necesario documentar, ni hacer pruebas unitarias. Igualmente si lo hace, tendrá puntos adicionales.

## Licencia
El código de este repositorio está bajo la licencia MIT (ver archivo LICENSE) y la documentación, bajo la licencia Creative Commons (CC-BY-SA-3.0).
